import React from 'react'

const Basic_Safety_Training = () => {
    return (
        <div>Basic_Safety_training</div>
    )
}

export default Basic_Safety_Training