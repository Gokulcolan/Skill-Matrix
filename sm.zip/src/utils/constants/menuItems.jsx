
export const AdminMenuItems = [
    {
        isNested: [
            {
                path: "/adminDashboard/safety",
                name: "Safety Training",
                // icon: <ContactPageIcon />,
            },
        ],
    },
];