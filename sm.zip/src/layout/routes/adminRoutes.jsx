import React from "react";
import RootLayout from "../nav/rootLayout";
import Basic_Safety_Training from "../../Pages/Admin/Basic&Safety";

const AdminRoutes = [
  {
    path: "/adminDashboard",
    element: <RootLayout />,
    children: [
      {
        path: "safetyTraining",
        element: <Basic_Safety_Training />,
      },
     
    ],
  },
];

export default AdminRoutes;
