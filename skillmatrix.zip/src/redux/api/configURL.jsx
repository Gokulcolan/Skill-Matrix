export const ADMIN_BASE_URL = process.env.REACT_APP_ADMIN_BASE_URL
  // ? process?.env?.REACT_APP_ADMIN_BASE_URL
  // : "";

console.log(ADMIN_BASE_URL, "ADMIN_BASE_URL2");
