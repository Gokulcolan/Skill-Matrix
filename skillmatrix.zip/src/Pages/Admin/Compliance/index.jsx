import React from 'react'

const Compliance = () => {
    return (
        <div>Attendance</div>
    )
}

export default Compliance