import React from 'react'

const Reporting = () => {
    return (
        <div>Level Analyser</div>
    )
}

export default Reporting