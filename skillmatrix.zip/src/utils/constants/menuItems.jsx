export const AdminMenuItems = [
  {
    isNested: [
      {
        path: "/adminDashboard/home",
        name: "Home",
      },
      {
        path: "/adminDashboard/safety",
        name: "Progress Card",
      },
      {
        path: "/adminDashboard/compliance",
        name: "Attendance",
      },
      {
        path: "/adminDashboard/reporting",
        name: "Level Analyser",
      },
     
    ],
  },
];
