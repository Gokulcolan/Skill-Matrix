
import React, { useEffect, useRef, useState } from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    TableFooter,
    Button,
    tableCellClasses,
} from "@mui/material";
import { styled } from "@mui/system";
import { useDispatch, useSelector } from "react-redux";
import { updateCycleTimeAchievementApi } from "../../../redux/action/adminAction";
import { showToast } from "../../Toast/toastServices";
import SignPopup from "../../Modal/signVerify";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: "#1976d2",
        color: "#fff",
        fontWeight: "bold",
        textAlign: "center",
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
        textAlign: "center",
    },
    [`&.${tableCellClasses.footer}`]: {
        backgroundColor: "#1976d2",
        color: "#fff",
        fontWeight: "bold",
        textAlign: "center",
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:nth-of-type(odd)": {
        backgroundColor: "rgb(0 0 0 / 4%)",
    },
    "&:last-child td, &:last-child th": {
        border: 0,
    },
}));

const MemorySecond = ({ data, cc, date }) => {

    const [open, setOpen] = useState(false);
    const [assessmentData, setAssessmentData] = useState([]);
    const { updateCycleTimeDetail } = useSelector((state) => state.admin);

    const dispatch = useDispatch();
    const isFirstRender = useRef(true);
    const previousDetail = useRef(null);

    useEffect(() => {
        if (data && data.length > 0) {
            const transformedData = data.map((exercise) => {
                // Mapping attempts with defaults if missing
                const attemptsArray = exercise.attempts.map((attempt) => ({
                    attempts_id: attempt.attempts_id || null,
                    mistakes: attempt.mistakes || "",
                    cycle_time: attempt.cycle_time || "",
                }));
                return {
                    ...exercise,
                    attempts: attemptsArray,
                    dct: exercise.dct || "",
                    status_: exercise.status_ || "",
                    remarks: exercise.remarks || "",
                    process_name: exercise.process_name || "",
                    demo_line_captain: exercise.demo_line_captain || "",
                    demo_trainee: exercise.demo_trainee || "",
                    cycle_achievement: exercise.cycle_achievement || "",
                    skill_matrix: exercise.skill_matrix || "",
                    actual_score: exercise.actual_score || "",
                    signByTrainee: exercise.sign.Signature_by_Trainee || "",
                    signByLineCaptain: exercise.sign.Signature_by_line_caption || "",
                    signByModuleController: exercise.sign.Signature_by_module_controller || "",
                    date: exercise.date || "",
                };
            });
            // console.log("Transformed Data:", transformedData);
            setAssessmentData(transformedData);
        }
    }, [data]);

    const handleValueChange = (exerciseIndex, field, attemptIndex, value) => {
        setAssessmentData((prevData) => {
            const updatedData = [...prevData];
            if (attemptIndex !== null) {
                updatedData[exerciseIndex].attempts[attemptIndex] = {
                    ...updatedData[exerciseIndex].attempts[attemptIndex],
                    [field]: value,
                };
            } else {
                updatedData[exerciseIndex][field] = value;
            }
            return updatedData;
        });
    };

    const handleSave = () => {
        const payload = {
            Cycle_time_achievement: assessmentData.map((exercise) => ({
                task_id: exercise.task_id,
                attempts: exercise.attempts.map((attempt, index) => ({
                    attempt_number: index + 1,
                    ...attempt,
                })),
                dct: exercise.dct,
                date: date,
                status_: exercise.status_,
                remarks: exercise.remarks,
                actual_score: exercise.actual_score,
                demo_line_captain: exercise.demo_line_captain,
                demo_trainee: exercise.demo_trainee,
                cycle_achievement: exercise.cycle_achievement,
                skill_matrix: exercise.skill_matrix,
                process_name: exercise.process_name,
                sign: {
                    Signature_by_Trainee: exercise.signByTrainee,
                    Signature_by_line_caption: exercise.signByLineCaptain,
                    Signature_by_module_controller: exercise.signByModuleController,
                },
            })),
            cc_no: cc,
        };
        dispatch(updateCycleTimeAchievementApi(payload));
    };

    useEffect(() => {

        if (isFirstRender.current) {
            isFirstRender.current = false; // Set to false after the first render
            previousDetail.current = updateCycleTimeDetail; // Set initial value
            return; // Skip showing toast on the first render
        }

        // Show toast only if updateEmployeeDetail has changed
        if (
            updateCycleTimeDetail &&
            updateCycleTimeDetail !== previousDetail.current
        ) {
            previousDetail.current = updateCycleTimeDetail; // Update the previous value
            if (updateCycleTimeDetail?.Status === "success") {
                showToast(updateCycleTimeDetail?.Message, "success");
            } else if (updateCycleTimeDetail?.Status === "fail") {
                showToast(updateCycleTimeDetail?.Message, "error");
            }
        }
    }, [updateCycleTimeDetail]);

    // useEffect(() => {
    //     if (updateCycleTimeDetail?.Status === 'success') {
    //         showToast(updateCycleTimeDetail?.Message, "success");
    //     } else if (updateCycleTimeDetail?.Status === 'fail') {
    //         showToast(updateCycleTimeDetail?.Message, "error");
    //     }
    // }, [updateCycleTimeDetail]);

    const handleSignVerify = () => {
        setOpen(true);
    };

    const handleSaveSignature = (signatureData) => {
        const updatedData = [...assessmentData];
        updatedData[0].signByTrainee = signatureData; // Update the specific field
        setAssessmentData(updatedData); // Ensure `setAssessmentData` updates state
        setOpen(false);
    };

    return (

        <TableContainer component={Paper} sx={{ mt: 2, mb: 2 }}>
            <Table stickyHeader>
                <TableHead>
                    <TableRow>
                        <StyledTableCell rowSpan={2}>JI Training - 5 Times Demo by Line Captain</StyledTableCell>
                        <StyledTableCell rowSpan={2}>JI Training - 5 Times by Trainee</StyledTableCell>
                        <StyledTableCell rowSpan={2}>Cycle Time Achievement</StyledTableCell>
                        <StyledTableCell rowSpan={2}>Update Skill Matrix</StyledTableCell>
                        <StyledTableCell rowSpan={2}>Process Name & Number</StyledTableCell>
                        <StyledTableCell rowSpan={2}>DCT</StyledTableCell>
                        <StyledTableCell colSpan={5}>Skill Assessment (Attempts)</StyledTableCell>
                        <StyledTableCell rowSpan={2}>Target Score</StyledTableCell>
                        <StyledTableCell rowSpan={2}>Actual Score</StyledTableCell>
                        <StyledTableCell rowSpan={2}>Status</StyledTableCell>
                        <StyledTableCell rowSpan={2}>Remarks</StyledTableCell>
                    </TableRow>
                    <TableRow>
                        {[1, 2, 3, 4, 5].map((attempt) => (
                            <StyledTableCell key={attempt}>{`Attempt ${attempt}`}</StyledTableCell>
                        ))}
                    </TableRow>
                </TableHead>
                <TableBody>
                    {assessmentData?.map((exercise, index) => (
                        <StyledTableRow key={index}>
                            <StyledTableCell>
                                <select
                                    value={exercise.demo_line_captain}
                                    onChange={(e) =>
                                        handleValueChange(index, "demo_line_captain", null, e.target.value)
                                    }
                                    className="field-drop-style"
                                >
                                    <option value="">Select Status</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </StyledTableCell>
                            <StyledTableCell>
                                <select
                                    value={exercise.demo_trainee}
                                    onChange={(e) =>
                                        handleValueChange(index, "demo_trainee", null, e.target.value)
                                    }
                                    className="field-drop-style"
                                >
                                    <option value="">Select Status</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </StyledTableCell>
                            <StyledTableCell>
                                <select
                                    value={exercise.cycle_achievement}
                                    onChange={(e) =>
                                        handleValueChange(index, "cycle_achievement", null, e.target.value)
                                    }
                                    className="field-drop-style"
                                >
                                    <option value="">Select Status</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </StyledTableCell>
                            <StyledTableCell>
                                <select
                                    value={exercise.skill_matrix}
                                    onChange={(e) =>
                                        handleValueChange(index, "skill_matrix", null, e.target.value)
                                    }
                                    className="field-drop-style"
                                >
                                    <option value="">Select Status</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </StyledTableCell>
                            <StyledTableCell>
                                <input
                                    type="text"
                                    placeholder="Process Name"
                                    value={exercise.process_name}
                                    onChange={(e) =>
                                        handleValueChange(index, "process_name", null, e.target.value)
                                    }
                                    className="field-style"
                                />
                            </StyledTableCell>
                            <StyledTableCell>
                                <input
                                    type="text"
                                    placeholder="Dct"
                                    value={exercise.dct}
                                    onChange={(e) =>
                                        handleValueChange(index, "dct", null, e.target.value)
                                    }
                                    className="field-style"
                                />
                            </StyledTableCell>
                            {exercise.attempts.map((attempt, attemptIndex) => (
                                <StyledTableCell key={attemptIndex}>
                                    <div>
                                        <input
                                            type="number"
                                            placeholder="Mistakes"
                                            value={attempt.mistakes}
                                            onChange={(e) =>
                                                handleValueChange(index, "mistakes", attemptIndex, e.target.value)
                                            }
                                            className="field-style"
                                        />
                                        <input
                                            type="text"
                                            placeholder="Cycle Time"
                                            value={attempt.cycle_time} op
                                            onChange={(e) =>
                                                handleValueChange(index, "cycle_time", attemptIndex, e.target.value)
                                            }
                                            className="field-style"
                                        />
                                    </div>
                                </StyledTableCell>
                            ))}
                            <StyledTableCell> &gt;93</StyledTableCell>
                            <StyledTableCell>
                                <input
                                    type="number"
                                    placeholder="Actual Score"
                                    value={exercise.actual_score}
                                    onChange={(e) =>
                                        handleValueChange(index, "actual_score", null, e.target.value)
                                    }
                                    className="field-style"
                                />
                            </StyledTableCell>
                            <StyledTableCell>
                                <select
                                    value={exercise.status_}
                                    onChange={(e) =>
                                        handleValueChange(index, "status_", null, e.target.value)
                                    }
                                    className="field-drop-style"
                                >
                                    <option value="">Select Status</option>
                                    <option value="Pass">Pass</option>
                                    <option value="Fail">Fail</option>
                                </select>
                            </StyledTableCell>
                            <StyledTableCell>
                                <input
                                    type="text"
                                    placeholder="Remarks"
                                    value={exercise.remarks}
                                    onChange={(e) =>
                                        handleValueChange(index, "remarks", null, e.target.value)
                                    }
                                    className="field-style"
                                />
                            </StyledTableCell>
                        </StyledTableRow>
                    ))}
                </TableBody>
                <TableFooter>
                    <TableRow>
                        <StyledTableCell colSpan={2}>Signature by Trainee</StyledTableCell>
                        <StyledTableCell colSpan={3}>
                            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }}>

                                {assessmentData[0]?.signByTrainee ? (
                                    <img
                                        src={
                                            typeof assessmentData[0]?.signByTrainee === "string" &&
                                                (assessmentData[0]?.signByTrainee.startsWith("http") ||
                                                    assessmentData[0]?.signByTrainee.startsWith("data:image"))
                                                ? assessmentData[0]?.signByTrainee
                                                : "https://via.placeholder.com/150"
                                        }
                                        alt="Profile"
                                        className="signature-img-cycle"
                                    />
                                ) : (
                                    ""
                                )}

                                <Button
                                    variant="outlined"
                                    onClick={() => handleSignVerify()}
                                    sx={{ backgroundColor: "white" }}
                                >
                                    Click here to Sign
                                </Button>
                            </div>
                        </StyledTableCell>
                        <StyledTableCell colSpan={2}>Signature by Line Captain</StyledTableCell>
                        <StyledTableCell colSpan={3}>
                            <input
                                type="text"
                                value={assessmentData[0]?.signByLineCaptain}
                                onChange={(e) =>
                                    handleValueChange(0, "signByLineCaptain", null, e.target.value)
                                }
                                className="field-style"
                            />
                        </StyledTableCell>
                        <StyledTableCell colSpan={2}>Signature by Module Controller</StyledTableCell>
                        <StyledTableCell colSpan={3}>
                            <input
                                type="text"
                                value={assessmentData[0]?.signByModuleController}
                                onChange={(e) =>
                                    handleValueChange(0, "signByModuleController", null, e.target.value)
                                }
                               className="field-style"
                            />
                        </StyledTableCell>
                    </TableRow>
                </TableFooter>
            </Table>
            <br />
            <Button
                variant="contained"
                color="success"
                sx={{ marginBottom: "16px" }}
                onClick={handleSave}
            >
                Save
            </Button>
            <SignPopup
                openModal={open}
                setOpenModal={() => setOpen(false)}
                onSave={handleSaveSignature}
            />
        </TableContainer>
    );
};

export default MemorySecond;

